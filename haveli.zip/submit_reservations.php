<?php
// No need for the debug lines anymore unless an issue persists
// ini_set('display_errors', 1);
// error_reporting(E_ALL);

require_once 'PHPMailer/src/PHPMailer.php';
require_once 'PHPMailer/src/SMTP.php';
require_once 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

// --- Validation ---
if (
    empty($_POST['name']) || 
    empty($_POST['phone']) || 
    empty($_POST['email']) ||
    empty($_POST['date']) || 
    empty($_POST['time']) || 
    empty($_POST['guests'])
) {
    echo json_encode(['success' => false, 'message' => 'Please fill in all required fields.']);
    exit;
}

if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Please provide a valid email address.']);
    exit;
}

try {
    require_once 'db_config.php';

    $db = getDBConnection();
    
    $num_guests = intval($_POST['guests']);
    $reservation_date = $_POST['date'];
    $reservation_time = $_POST['time'];
    $customer_name = htmlspecialchars($_POST['name']);
    $customer_email = htmlspecialchars($_POST['email']);
    $customer_phone = htmlspecialchars($_POST['phone']);

    // Insert the reservation as "Pending"
    $stmt = $db->prepare(
        "INSERT INTO reservations (customer_name, phone_number, email, num_guests, reservation_date, reservation_time, status) 
         VALUES (?, ?, ?, ?, ?, ?, 'Pending')"
    );
    
    $stmt->execute([
        $customer_name,
        $customer_phone,
        $customer_email,
        $num_guests,
        $reservation_date,
        $reservation_time
    ]);

    // INSTANT RESPONSE: Queue emails for background processing
    // This provides immediate feedback to the user without waiting for email delivery
    
    require_once 'email_templates.php';
    
    // Queue customer email for background processing (instant UX)
    $customer_email_queue = [
        'customer' => [
            'to' => $customer_email,
            'to_name' => $customer_name,
            'subject' => 'Reservation Request Received - Haveli Restaurant',
            'template' => 'request_received',
            'data' => [
                'customer_name' => $customer_name,
                'reservation_date' => $reservation_date,
                'reservation_time' => $reservation_time,
                'num_guests' => $num_guests
            ]
        ]
    ];
    
    // Save customer email to queue for background processing
    $queue_file_customer = 'admin/email_queue_customer_' . time() . '_' . rand(1000, 9999) . '.json';
    @file_put_contents($queue_file_customer, json_encode($customer_email_queue));
    
    // Queue admin email for background processing (fast response)
    $admin_email_queue = [
        'admin' => [
            'to' => 'info@haveli.co.uk',
            'to_name' => 'Haveli Admin',
            'subject' => 'New Reservation Request - Action Required',
            'body' => "A new reservation request has been received:<br><br>"
                    . "<strong>Customer Name:</strong> {$customer_name}<br>"
                    . "<strong>Phone:</strong> {$customer_phone}<br>"
                    . "<strong>Email:</strong> {$customer_email}<br>"
                    . "<strong>Date:</strong> {$reservation_date}<br>"
                    . "<strong>Time:</strong> {$reservation_time}<br>"
                    . "<strong>Number of Guests:</strong> {$num_guests}<br><br>"
                    . "Please login to the admin dashboard to confirm or decline this reservation."
        ]
    ];
    
    // Save admin email to queue for background processing
    $queue_file_admin = 'admin/email_queue_admin_' . time() . '_' . rand(1000, 9999) . '.json';
    @file_put_contents($queue_file_admin, json_encode($admin_email_queue));

    // Trigger robust email processing in background (non-blocking)
    if (function_exists('exec')) {
        $php_path = PHP_BINARY;
        $script_path = __DIR__ . '/admin/robust_email_processor.php';
        
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            // Windows - run in background without blocking
            exec("start /B \"\" \"$php_path\" \"$script_path\" > nul 2>&1", $output, $return_var);
        } else {
            // Linux/Mac - run in background
            exec("$php_path \"$script_path\" > /dev/null 2>&1 &", $output, $return_var);
        }
    }
    
    echo json_encode([
        'success' => true, 
        'message' => 'Reservation request sent successfully! We will contact you to confirm.'
    ]);
    exit;

} catch (PDOException $e) {
    error_log("Database Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'A server error occurred. Please try again later.']);
    exit;
}
?>