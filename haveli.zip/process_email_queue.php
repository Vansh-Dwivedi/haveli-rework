<?php
/**
 * Automatic Email Queue Processor
 * - Scans local JSON queue files and sends emails via PHPMailer
 * - Safe to call via AJAX from the dashboard
 */

header('Content-Type: application/json');

// SMTP configuration (Zoho)
$SMTP_HOST = 'smtppro.zoho.eu';
$SMTP_PORT = 465;
$SMTP_SECURE = 'ssl';
$SMTP_USER = 'info@haveli.co.uk';

// Retrieve SMTP password securely (env first, then local file)
$SMTP_PASS = getenv('HAVELI_SMTP_PASS');
if (!$SMTP_PASS && file_exists(__DIR__ . '/smtp_password.php')) {
    // Optional local file returning $SMTP_PASSWORD
    include __DIR__ . '/smtp_password.php';
    if (isset($SMTP_PASSWORD) && $SMTP_PASSWORD) {
        $SMTP_PASS = $SMTP_PASSWORD;
    }
}

// Include dependencies
require_once __DIR__ . '/email_templates.php';
require_once __DIR__ . '/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/src/SMTP.php';
require_once __DIR__ . '/PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function load_queue_files($pattern) {
    $files = glob($pattern);
    return $files ? $files : [];
}

try {
    // Queue files live in project root and start with email_queue_
    $queue_files = load_queue_files(__DIR__ . '/email_queue_*.json');

    if (empty($queue_files)) {
        echo json_encode(['success' => true, 'message' => 'No emails in queue', 'processed' => 0, 'remaining' => 0]);
        exit;
    }

    if (!$SMTP_PASS) {
        echo json_encode([
            'success' => false,
            'message' => 'SMTP password not configured. Set HAVELI_SMTP_PASS env or create smtp_password.php with $SMTP_PASSWORD.',
            'processed' => 0,
            'remaining' => count($queue_files)
        ]);
        exit;
    }

    $processed = 0;
    $failed = 0;
    $errors = [];

    foreach ($queue_files as $file) {
        $payload = json_decode(file_get_contents($file), true);
        if (!$payload || !isset($payload['customer'])) {
            $errors[] = basename($file) . ': invalid queue format';
            $failed++;
            continue;
        }

        $job = $payload['customer'];
        $to = $job['to'] ?? '';
        $to_name = $job['to_name'] ?? '';
        $subject = $job['subject'] ?? 'Haveli Restaurant';
        $template = $job['template'] ?? '';
        $data = $job['data'] ?? [];

        if (!$to) {
            $errors[] = basename($file) . ': missing recipient address';
            $failed++;
            continue;
        }

        // Build HTML body from template
        $htmlBody = '';
        if ($template === 'confirmation') {
            $htmlBody = getConfirmationEmailTemplate(
                $data['customer_name'] ?? 'Guest',
                $data['reservation_date'] ?? '',
                $data['reservation_time'] ?? '',
                $data['num_guests'] ?? ''
            );
        } elseif ($template === 'request') {
            $htmlBody = getRequestReceivedTemplate(
                $data['customer_name'] ?? 'Guest',
                $data['reservation_date'] ?? '',
                $data['reservation_time'] ?? '',
                $data['num_guests'] ?? ''
            );
        } else {
            // Unknown template: send plain message
            $htmlBody = '<p>Thank you from Haveli Restaurant.</p>';
        }

        $mail = new PHPMailer(true);
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = $SMTP_HOST;
            $mail->SMTPAuth = true;
            $mail->Username = $SMTP_USER;
            $mail->Password = $SMTP_PASS;
            $mail->SMTPSecure = $SMTP_SECURE;
            $mail->Port = $SMTP_PORT;
            $mail->CharSet = 'UTF-8';

            // Recipients
            $mail->setFrom($SMTP_USER, 'Haveli Restaurant');
            $mail->addAddress($to, $to_name);

            // Content
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $htmlBody;

            $mail->send();

            // On success, delete queue file
            @unlink($file);
            $processed++;
        } catch (Exception $e) {
            // Update retry count in queue file
            $payload['customer']['retry_count'] = isset($payload['customer']['retry_count']) ? ((int)$payload['customer']['retry_count'] + 1) : 1;
            file_put_contents($file, json_encode($payload, JSON_PRETTY_PRINT));
            $failed++;
            $errors[] = basename($file) . ': ' . $e->getMessage();
        }
    }

    $remaining = count(load_queue_files(__DIR__ . '/email_queue_*.json'));
    echo json_encode([
        'success' => $failed === 0,
        'message' => "Processed $processed, Failed $failed",
        'processed' => $processed,
        'failed' => $failed,
        'remaining' => $remaining,
        'errors' => $errors
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error processing emails: ' . $e->getMessage()
    ]);
}
?>